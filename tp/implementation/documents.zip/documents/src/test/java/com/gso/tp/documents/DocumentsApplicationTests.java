package com.gso.tp.documents;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DocumentsApplicationTests {

	@Test
	void contextLoads() {
	}

}
